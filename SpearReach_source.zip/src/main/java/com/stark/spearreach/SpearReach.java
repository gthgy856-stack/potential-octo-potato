package com.stark.spearreach;

import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class SpearReach extends JavaPlugin implements Listener {

    private double reach;
    private double hitboxMargin;
    private double maxAngle;
    private boolean throughWalls;
    private boolean playersOnly;
    private int cooldownTicks;
    private final Set<String> worlds = new HashSet<>();

    // آخر تيك صار فيه ضرب عادي (من الكلاينت) لكل لاعب — عشان ما نضرب مرتين
    private final Map<UUID, Integer> lastVanillaHitTick = new HashMap<>();
    // آخر تيك ضربنا فيه بالمدى الممدود
    private final Map<UUID, Integer> lastReachHitTick = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("SpearReach enabled — reach " + reach + " blocks, max angle " + maxAngle + ".");
    }

    private void loadSettings() {
        reloadConfig();
        reach = Math.max(0.5, getConfig().getDouble("reach", 3.0));
        hitboxMargin = Math.max(0.0, getConfig().getDouble("hitbox-margin", 0.3));
        maxAngle = Math.max(1.0, Math.min(180.0, getConfig().getDouble("max-angle", 100.0)));
        throughWalls = getConfig().getBoolean("through-walls", false);
        playersOnly = getConfig().getBoolean("players-only", true);
        cooldownTicks = Math.max(1, getConfig().getInt("cooldown-ticks", 12));
        worlds.clear();
        worlds.addAll(getConfig().getStringList("worlds"));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("spearreach.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            loadSettings();
            sender.sendMessage("§aSpearReach reloaded — reach " + reach + " blocks.");
            return true;
        }

        if (args.length == 2 && args[0].equalsIgnoreCase("set")) {
            double value;
            try {
                value = Double.parseDouble(args[1]);
            } catch (NumberFormatException ex) {
                sender.sendMessage("§cInvalid number: " + args[1]);
                return true;
            }
            if (Double.isNaN(value) || Double.isInfinite(value) || value < 0.5 || value > 10.0) {
                sender.sendMessage("§cReach must be between 0.5 and 10.");
                return true;
            }
            // يُحفظ في config.yml على الديسك، ويبقى بعد الريستارت
            getConfig().set("reach", value);
            saveConfig();
            reach = value;
            sender.sendMessage("§aSpear reach set to " + value + " blocks (saved to config.yml).");
            return true;
        }

        sender.sendMessage("§eCurrent reach: §f" + reach + " blocks");
        sender.sendMessage("§e/spearreach set <blocks>  §7- change and save");
        sender.sendMessage("§e/spearreach reload        §7- reload config.yml");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("spearreach.admin")) return List.of();
        if (args.length == 1) return List.of("set", "reload");
        if (args.length == 2 && args[0].equalsIgnoreCase("set")) return List.of("3", "4", "5");
        return List.of();
    }

    private static boolean isSpear(ItemStack item) {
        return item != null && item.getType().name().endsWith("_SPEAR");
    }

    // الضرب العادي: الكلاينت يرسل ضرب الكيان قبل حركة اليد، فنسجله ونتجاوز نفس التيك
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) {
            lastVanillaHitTick.put(player.getUniqueId(), Bukkit.getCurrentTick());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;

        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.SPECTATOR) return;
        if (player.hasPermission("spearreach.bypass")) return;
        if (!isSpear(player.getInventory().getItemInMainHand())) return;
        if (!worlds.isEmpty() && !worlds.contains(player.getWorld().getName())) return;

        int now = Bukkit.getCurrentTick();
        UUID id = player.getUniqueId();

        Integer vanilla = lastVanillaHitTick.get(id);
        if (vanilla != null && now - vanilla <= 1) return;

        Integer last = lastReachHitTick.get(id);
        if (last != null && now - last < cooldownTicks) return;

        LivingEntity target = findTarget(player);
        if (target == null) return;

        lastReachHitTick.put(id, now);
        player.attack(target);
    }

    // يدوّر على أقرب هدف داخل المدى، حتى لو اللاعب ما يطالعه مباشرة (حسب max-angle).
    // الأولوية للي أقرب لاتجاه النظر، وبعدها الأقرب مسافة.
    private LivingEntity findTarget(Player player) {
        Location eye = player.getEyeLocation();
        Vector eyeVec = eye.toVector();
        Vector look = eye.getDirection();

        double search = reach + hitboxMargin + 1.0;
        LivingEntity best = null;
        double bestAngle = Double.MAX_VALUE;
        double bestDist = Double.MAX_VALUE;

        for (Entity entity : player.getNearbyEntities(search, search, search)) {
            if (!isValidTarget(player, entity)) continue;
            LivingEntity living = (LivingEntity) entity;

            BoundingBox box = living.getBoundingBox().expand(hitboxMargin);
            Vector point = new Vector(
                    clamp(eyeVec.getX(), box.getMinX(), box.getMaxX()),
                    clamp(eyeVec.getY(), box.getMinY(), box.getMaxY()),
                    clamp(eyeVec.getZ(), box.getMinZ(), box.getMaxZ()));

            Vector toPoint = point.clone().subtract(eyeVec);
            double dist = toPoint.length();
            if (dist > reach) continue;

            double angle = 0.0;
            Vector dir = null;
            if (dist > 1.0E-6) {
                dir = toPoint.clone().multiply(1.0 / dist);
                // الزاوية أفقية فقط (يمين/يسار/قدام/ورا)، فالنظر لفوق أو تحت ما يضيّق المدى
                double lx = look.getX(), lz = look.getZ();
                double dx = dir.getX(), dz = dir.getZ();
                double lLen = Math.sqrt(lx * lx + lz * lz);
                double dLen = Math.sqrt(dx * dx + dz * dz);
                if (lLen > 1.0E-6 && dLen > 1.0E-6) {
                    double dot = (lx * dx + lz * dz) / (lLen * dLen);
                    angle = Math.toDegrees(Math.acos(Math.max(-1.0, Math.min(1.0, dot))));
                }
            }
            if (angle > maxAngle) continue;

            if (!throughWalls && dir != null) {
                RayTraceResult block = player.getWorld().rayTraceBlocks(
                        eye, dir, dist, FluidCollisionMode.NEVER, true);
                if (block != null) continue;
            }

            if (angle < bestAngle || (angle == bestAngle && dist < bestDist)) {
                best = living;
                bestAngle = angle;
                bestDist = dist;
            }
        }
        return best;
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private boolean isValidTarget(Player attacker, Entity entity) {
        if (entity.equals(attacker)) return false;
        if (!(entity instanceof LivingEntity living)) return false;
        if (playersOnly && !(entity instanceof Player)) return false;
        if (living.isDead() || !living.isValid()) return false;
        if (living instanceof Player other && other.getGameMode() == GameMode.SPECTATOR) return false;
        return true;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        lastVanillaHitTick.remove(id);
        lastReachHitTick.remove(id);
    }
}
